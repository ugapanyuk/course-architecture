﻿using Microsoft.Extensions.DependencyInjection;
using System;
using System.Collections.Generic;
using System.Text;

namespace Seminar_5;

class BookCatalogService_Anti_BI
{
    private ILogger _logger;

    /// <summary>
    /// Конструктор «для удобства»: создаёт логгер самостоятельно.
    /// Кажется полезным — на деле скрывает зависимость.
    /// </summary>
    public BookCatalogService_Anti_BI() : this(new ConsoleLogger()) { }

    /// <summary>
    /// Конструктор с внедрением: принимает логгер снаружи.
    /// </summary>
    public BookCatalogService_Anti_BI(ILogger logger)
    {
        _logger = logger;
    }

    public void AddBook(string title, string author)
    {
        _logger.Log($"Добавлена книга: «{title}» — {author}");
    }
}

/*
/// <summary>
/// Глобальный реестр зависимостей — антипаттерн Service Locator.
/// </summary>
static class ServiceLocator
{
    private static ServiceProvider _provider;

    public static void Init(ServiceProvider provider) { _provider = provider; }

    public static T Get<T>() => _provider.GetRequiredService<T>();
}

class BookCatalogService_Anti_SL
{
    public void AddBook(string title, string author)
    {
        // Зависимости запрашиваются внутри метода — скрытая связанность
        ILogger logger = ServiceLocator.Get<ILogger>();
        IBookStorage storage = ServiceLocator.Get<IBookStorage>();

        storage.Save(title, author);
        logger.Log($"Добавлена книга: «{title}» — {author}");
    }
}
*/


/// <summary>
/// Глобальный контекст логгера — антипаттерн Ambient Context.
/// </summary>
static class LoggerContext
{
    // Глобальное состояние, доступное для изменения из любого места программы
    public static ILogger Current { get; set; } = new NullLogger();
}

class BookCatalogService_LC
{
    // Конструктор пуст — зависимость скрыта
    public void AddBook(string title, string author)
    {
        // Зависимость берётся из глобального контекста — неявная связь
        LoggerContext.Current.Log($"Добавлена книга: «{title}» — {author}");
    }

    public void RemoveBook(string title)
    {
        LoggerContext.Current.Log($"Удалена книга: «{title}»");
    }
}




