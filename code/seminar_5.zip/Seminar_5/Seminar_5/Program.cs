﻿using Microsoft.Extensions.DependencyInjection;

namespace Seminar_5;

internal class Program
{
    static void Main(string[] args)
    {
        // Основная программа
        Console.WriteLine("=== Наивная реализация ===");
        NaiveBookCatalogService service = new();
        service.AddBook("Евгений Онегин", "Пушкин");
        service.RemoveBook("Евгений Онегин");


        Console.WriteLine("=== Внедрение через конструктор ===");
        // Передаём ConsoleLogger
        BookCatalogService_DI_Constructor s1 = new BookCatalogService_DI_Constructor(new ConsoleLogger());
        s1.AddBook("Евгений Онегин", "Пушкин");

        // Передаём FileLogger — код BookCatalogService не трогаем!
        BookCatalogService_DI_Constructor s2 = new BookCatalogService_DI_Constructor(new FileLogger("log.txt"));
        s2.AddBook("Сборник стихотворений", "Пушкин");


        Console.WriteLine("=== Внедрение через свойство ===");
        BookCatalogService_DI_Property s3 = new();

        // Без логгера — NullLogger работает молча, никакого вывода
        s3.AddBook("Евгений Онегин", "Пушкин");

        // Подключаем логгер через свойство
        s3.Logger = new ConsoleLogger();
        s3.AddBook("Сборник стихотворений", "Пушкин"); // теперь событие пишется в консоль


        Console.WriteLine("=== Внедрение через параметр метода ===");
        BookCatalogService_DI_Method s4 = new BookCatalogService_DI_Method();
        // Разные операции могут логироваться по-разному
        s4.AddBook("Евгений Онегин", "Пушкин", new ConsoleLogger());
        s4.AddBook("Сборник стихотворений", "Пушкин", new FileLogger("audit.log"));


        Console.WriteLine("=== Точка сборки ===");
        ILogger logger = new ConsoleLogger();
        IBookStorage storage = new InMemoryBookStorage(logger);
        BookCatalogService s5 = new BookCatalogService(logger, storage);
        s5.AddBook("Евгений Онегин", "Пушкин");
        s5.AddBook("Сборник стихотворений", "Пушкин");


        Console.WriteLine("=== Точка сборки с фреймворком ===");
        // Шаг 1 — создаём коллекцию описаний зависимостей
        ServiceCollection services = new ServiceCollection();

        // Шаг 2 — регистрация: говорим контейнеру,
        // какой конкретный класс использовать для каждого интерфейса
        services.AddSingleton<ILogger, ConsoleLogger>();
        services.AddSingleton<IBookStorage, InMemoryBookStorage>();
        services.AddTransient<BookCatalogService>();

        // Шаг 3 — строим контейнер (после этого регистрация закрыта)
        ServiceProvider provider = services.BuildServiceProvider(
            new ServiceProviderOptions { ValidateOnBuild = true }
        );

        // Шаг 4 — разрешение: просим контейнер создать нужный объект
        // Контейнер сам строит граф: BookCatalogService → ILogger, IBookStorage
        //                                InMemoryBookStorage → ILogger
        BookCatalogService s7 = provider.GetRequiredService<BookCatalogService>();
        // Работаем с объектом как обычно
        s7.AddBook("Евгений Онегин", "Пушкин");

    }
}
