﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Seminar_5;


/// <summary>
/// Контракт для записи журнала событий.
/// Интерфейс определяется исходя из потребностей того,
/// кто его использует, а не того, кто его реализует.
/// </summary>
interface ILogger
{
    void Log(string message);
}

/// <summary>
/// Логгер: выводит сообщения в консоль
/// </summary>
class ConsoleLogger : ILogger
{
    public void Log(string message)
    {
        Console.WriteLine($"[LOG] {message}");
    }
}

/// <summary>
/// Логгер: записывает сообщения в файл
/// </summary>
class FileLogger : ILogger
{
    private string _filePath;

    public FileLogger(string filePath) { _filePath = filePath; }

    public void Log(string message)
    {
        File.AppendAllText(_filePath, $"[LOG] {message}\n");
    }
}

/// <summary>
/// Логгер-заглушка: ничего не делает.
/// Применяется как безопасное значение по умолчанию вместо null.
/// </summary>
class NullLogger : ILogger
{
    // Метод ничего не делает
    public void Log(string message) { }
}


/// <summary>
/// Сервис каталога книг.
/// Зависит от абстракции ILogger, а не от конкретного класса.
/// </summary>
class BookCatalogService_DI_Constructor
{
    private ILogger _logger;

    /// <summary>
    /// Зависимость передаётся снаружи — класс её не создаёт.
    /// Зависимость внедряется через конструктор
    /// </summary>
    public BookCatalogService_DI_Constructor(ILogger logger)
    {
        _logger = logger;
    }

    public void AddBook(string title, string author)
    {
        // ... логика сохранения книги ...
        _logger.Log($"Добавлена книга: «{title}» — {author}");
    }

    public void RemoveBook(string title)
    {
        // ... логика удаления ...
        _logger.Log($"Удалена книга: «{title}»");
    }
}

/// <summary>
/// Сервис каталога книг с необязательным логгером.
/// </summary>
class BookCatalogService_DI_Property
{
    /// <summary>
    /// Необязательная зависимость.
    /// Если не задана — используется NullLogger (ничего не делает).
    /// </summary>
    public ILogger Logger { get; set; } = new NullLogger();

    public void AddBook(string title, string author)
    {
        // ... логика сохранения книги ...
        Logger.Log($"Добавлена книга: «{title}» — {author}");
    }

    public void RemoveBook(string title)
    {
        // ... логика удаления ...
        Logger.Log($"Удалена книга: «{title}»");
    }
}


/// <summary>
/// Сервис каталога книг.
/// Логгер передаётся отдельно для каждой операции.
/// </summary>
class BookCatalogService_DI_Method
{
    // Поля нет — логгер приходит с каждым вызовом
    public void AddBook(string title, string author, ILogger logger)
    {
        // ... логика сохранения книги ...
        logger.Log($"Добавлена книга: «{title}» — {author}");
    }
}


/// <summary>
/// Контракт для хранения книг
/// </summary>
interface IBookStorage
{
    void Save(string title, string author);
}

/// <summary>
/// Хранение книг в оперативной памяти
/// </summary>
class InMemoryBookStorage : IBookStorage
{
    private ILogger _logger;
    private List<string> _books = new();

    public InMemoryBookStorage(ILogger logger) { _logger = logger; }

    public void Save(string title, string author)
    {
        _books.Add($"«{title}» — {author}");
        _logger.Log($" [STORAGE] Сохранено: «{title}»");
    }
}


/// <summary>
/// Сервис каталога книг.
/// Зависит только от интерфейсов — ни одного конкретного класса.
/// </summary>
class BookCatalogService
{
    private ILogger _logger;
    private IBookStorage _storage;

    public BookCatalogService(ILogger logger, IBookStorage storage)
    {
        _logger = logger;
        _storage = storage;
    }

    public void AddBook(string title, string author)
    {
        _storage.Save(title, author);
        _logger.Log($"Добавлена книга: «{title}» — {author}");
    }

    public void RemoveBook(string title)
    {
        _logger.Log($"Удалена книга: «{title}»");
    }
}
