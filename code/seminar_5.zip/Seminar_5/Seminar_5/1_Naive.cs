﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Seminar_5;

/// <summary>
/// Логгер: выводит сообщения в консоль
/// </summary>
class NaiveConsoleLogger
{
    public void Log(string message)
    {
        Console.WriteLine($"[LOG] {message}");
    }
}

/// <summary>
/// Логгер: записывает сообщения в файл
/// </summary>
class NaiveFileLogger
{
    private string _filePath;

    public NaiveFileLogger(string filePath) { _filePath = filePath; }

    public void Log(string message)
    {
        File.AppendAllText(_filePath, $"[LOG] {message}\n");
    }
}

/// <summary>
/// Сервис каталога книг
/// </summary>
class NaiveBookCatalogService
{
    // Логгер создаётся прямо здесь, внутри класса
    // ЭТО ОСНОВНАЯ ПРОБЛЕМА
    private NaiveConsoleLogger _logger = new NaiveConsoleLogger();
    // Чтобы сменить логгер — нужно поменять класс сервиса
    // private NaiveFileLogger _logger = new NaiveFileLogger("catalog.log");

    public void AddBook(string title, string author)
    {
        // ... здесь была бы логика сохранения книги ...
        _logger.Log($"Добавлена книга: «{title}» — {author}");
    }

    public void RemoveBook(string title)
    {
        // ... здесь была бы логика удаления ...
        _logger.Log($"Удалена книга: «{title}»");
    }
}

/// <summary>
/// Логирование с флагом
/// </summary>
class NaiveBookCatalogServiceLogFlag
{
    private bool _useFile;

    public NaiveBookCatalogServiceLogFlag(bool useFile = false) { _useFile = useFile; }

    public void AddBook(string title, string author)
    {
        if (_useFile)
            File.AppendAllText("log.txt", $"Добавлена книга: «{title}»\n");
        else
            Console.WriteLine($"[LOG] Добавлена книга: «{title}»");
    }

    // ... и в каждом методе тот же if/else ...
}
