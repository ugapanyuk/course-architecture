﻿using System;
using System.IO;

// ================= ЧТЕНИЕ ФАЙЛА POEM.TXT =================

string poemFile = Path.Combine(AppContext.BaseDirectory, "poem.txt");

// Проверка существования файла (раздел 7.1)
if (!File.Exists(poemFile))
{
    Console.WriteLine($"Файл не найден: {poemFile}");
    return;
}

Console.WriteLine("════════════════════════════════════");
Console.WriteLine("  Способ 1: try/finally без using   ");
Console.WriteLine("════════════════════════════════════");
ReadWithTryFinally(poemFile);

Console.WriteLine();
Console.WriteLine("════════════════════════════════════");
Console.WriteLine("  Способ 2: классический using { }  ");
Console.WriteLine("════════════════════════════════════");
ReadWithUsing(poemFile);

Console.WriteLine();
Console.WriteLine("════════════════════════════════════");
Console.WriteLine("  Способ 3: using declaration (C#8) ");
Console.WriteLine("════════════════════════════════════");
ReadWithUsingDeclaration(poemFile);

// ================= ФУНКЦИИ =================

/// <summary>
/// Чтение файла с помощью try/finally — явное освобождение ресурса.
/// Демонстрирует то, во что компилятор разворачивает оператор using.
/// </summary>
/// <param name="filePath">Путь к текстовому файлу</param>
static void ReadWithTryFinally(string filePath)
{
    StreamReader reader = null;

    try
    {
        // Открываем файл для чтения
        reader = new StreamReader(filePath);

        Console.WriteLine($"Файл открыт: {Path.GetFileName(filePath)}");
        Console.WriteLine(new string('-', 36));

        int lineNumber = 1;
        string line;

        // ReadLine возвращает null когда файл прочитан до конца
        while ((line = reader.ReadLine()) != null)
        {
            Console.WriteLine($"{lineNumber,3}: {line}");
            lineNumber++;
        }

        Console.WriteLine(new string('-', 36));
        Console.WriteLine($"Прочитано строк: {lineNumber - 1}");
    }
    finally
    {
        // Dispose() вызывается явно в блоке finally.
        // Оператор ?. защищает от ошибки если reader == null
        // (например, если файл не удалось открыть)
        reader?.Dispose();
        Console.WriteLine("StreamReader закрыт в блоке finally.");
    }
}

/// <summary>
/// Чтение файла с помощью классического оператора using.
/// Dispose() вызывается автоматически при выходе из блока using,
/// в том числе при возникновении исключения.
/// </summary>
/// <param name="filePath">Путь к текстовому файлу</param>
static void ReadWithUsing(string filePath)
{
    // Компилятор автоматически разворачивает этот блок
    // в конструкцию try/finally как в примере выше
    using (StreamReader reader = new StreamReader(filePath))
    {
        Console.WriteLine($"Файл открыт: {Path.GetFileName(filePath)}");
        Console.WriteLine(new string('-', 36));

        int lineNumber = 1;
        string line;

        while ((line = reader.ReadLine()) != null)
        {
            Console.WriteLine($"{lineNumber,3}: {line}");
            lineNumber++;
        }

        Console.WriteLine(new string('-', 36));
        Console.WriteLine($"Прочитано строк: {lineNumber - 1}");

    } // Dispose() вызывается автоматически здесь
    Console.WriteLine("StreamReader закрыт автоматически.");
}

/// <summary>
/// Чтение файла с помощью using declaration — синтаксис C# 8.
/// Dispose() вызывается в конце области видимости метода.
/// Код короче: не нужны фигурные скобки блока using.
/// </summary>
/// <param name="filePath">Путь к текстовому файлу</param>
static void ReadWithUsingDeclaration(string filePath)
{
    // using перед объявлением переменной — конструкция C# 8
    // StreamReader будет закрыт в конце метода
    using StreamReader reader = new StreamReader(filePath);

    Console.WriteLine($"Файл открыт: {Path.GetFileName(filePath)}");
    Console.WriteLine(new string('-', 36));

    int lineNumber = 1;
    string line;

    while ((line = reader.ReadLine()) != null)
    {
        Console.WriteLine($"{lineNumber,3}: {line}");
        lineNumber++;
    }

    Console.WriteLine(new string('-', 36));
    Console.WriteLine($"Прочитано строк: {lineNumber - 1}");

} // Dispose() вызывается автоматически здесь — в конце метода
