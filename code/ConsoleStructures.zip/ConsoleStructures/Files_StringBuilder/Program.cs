﻿using System;
using System.IO;
using System.Text;

// ================= ФОРМИРОВАНИЕ ОТЧЁТА =================

// Исходные данные для отчёта
string[] subjects = { "Математика", "Физика", "Информатика",
                      "История",   "Химия",  "Английский" };

int[] scores = { 85, 92, 98, 76, 81, 88 };

string reportFile = Path.Combine(AppContext.BaseDirectory, "report.txt");

// Формирование отчёта и запись в файл
BuildAndSaveReport(subjects, scores, reportFile);

// Чтение файла и вывод содержимого (раздел 7.2)
Console.WriteLine("Содержимое сохранённого файла:");
Console.WriteLine(new string('=', 40));
foreach (string line in File.ReadLines(reportFile))
{
    Console.WriteLine(line);
}

// ================= ФУНКЦИИ =================

/// <summary>
/// Формирует текстовый отчёт с помощью StringBuilder
/// и сохраняет его в файл
/// </summary>
/// <param name="subjects">Массив названий предметов</param>
/// <param name="scores">Массив оценок</param>
/// <param name="filePath">Путь к файлу для сохранения отчёта</param>
static void BuildAndSaveReport(string[] subjects,
                               int[] scores,
                               string filePath)
{
    StringBuilder sb = new StringBuilder();

    // Заголовок отчёта
    sb.AppendLine("========================================");
    sb.AppendLine("           ОТЧЁТ ОБ УСПЕВАЕМОСТИ       ");
    sb.AppendLine("========================================");
    sb.AppendFormat("Дата формирования: {0:dd.MM.yyyy HH:mm}\n",
        DateTime.Now);
    sb.AppendLine("----------------------------------------");

    // Формирование строк таблицы в цикле.
    // Если бы здесь использовался оператор «+»,
    // при каждой итерации создавался бы новый объект String
    int totalScore = 0;

    for (int i = 0; i < subjects.Length; i++)
    {
        string grade = GetGrade(scores[i]);

        // AppendFormat — форматированная строка с выравниванием
        sb.AppendFormat("{0,-15} {1,3} балла   {2}\n",
            subjects[i], scores[i], grade);

        totalScore += scores[i];
    }

    // Итоговая строка
    double average = (double)totalScore / scores.Length;

    sb.AppendLine("----------------------------------------");
    sb.AppendFormat("Средний балл:   {0:F1}\n", average);
    sb.AppendFormat("Всего предметов: {0}\n", subjects.Length);
    sb.AppendLine("========================================");

    // ToString() — получение итоговой строки из буфера
    string reportText = sb.ToString();

    // Запись в файл методом File.WriteAllText (раздел 7.2)
    File.WriteAllText(filePath, reportText);

    Console.WriteLine($"Отчёт сохранён: {filePath}");
    Console.WriteLine($"Размер отчёта:  {reportText.Length} символов");
    Console.WriteLine();
}

/// <summary>
/// Возвращает текстовую оценку по числовому баллу
/// </summary>
/// <param name="score">Числовой балл</param>
/// <returns>Текстовая оценка</returns>
static string GetGrade(int score)
{
    return score switch
    {
        >= 90 => "Отлично",
        >= 75 => "Хорошо",
        >= 60 => "Удовлетворительно",
        _ => "Неудовлетворительно"
    };
}
