﻿using System.IO;

// Проверка существования каталога
string catalogName = @"c:\";

if (Directory.Exists(catalogName))
{
    Console.WriteLine("Каталог существует: " + catalogName);
}
else
{
    Console.WriteLine("Каталог не найден: " + catalogName);
}

//Пример создания каталога при его отсутствии:
string outputDir = @"c:\output";

if (!Directory.Exists(outputDir))
{
    Directory.CreateDirectory(outputDir);
    Console.WriteLine("Каталог создан: " + outputDir);
}

//Пример вывода списка файлов и каталогов в корне диска «С»
Console.WriteLine("\nСписок файлов каталога " + catalogName);
string[] files = Directory.GetFiles(catalogName);
foreach (string file in files)
{
    Console.WriteLine(file);
}

Console.WriteLine("\nСписок подкаталогов каталога " + catalogName);
string[] dirs = Directory.GetDirectories(catalogName);
foreach (string dir in dirs)
{
    Console.WriteLine(dir);
}


//Пример фильтрации файлов по маске
// Только текстовые файлы
string[] txtFiles = Directory.GetFiles(catalogName, "*.txt");

// Файлы, имя которых начинается на "report"
string[] reportFiles = Directory.GetFiles(catalogName, "report*.*");

Console.WriteLine($"Найдено txt-файлов: {txtFiles.Length}");
foreach (string file in txtFiles)
{
    Console.WriteLine(file);
}

// Пример рекурсивного поиска по подкаталогам
// Только в указанном каталоге
// Параметр "SearchOption.TopDirectoryOnly" можно не указывать, он установлен по умолчанию
string catalogName2 = @"c:\python";
string[] files1 = Directory.GetFiles(catalogName2, "*.txt", SearchOption.TopDirectoryOnly);

// Во всех вложенных подкаталогах
string[] files2 = Directory.GetFiles(catalogName2, "*.txt", SearchOption.AllDirectories);

Console.WriteLine($"В каталоге: {files1.Length} файлов");
Console.WriteLine($"В каталоге и подкаталогах: {files2.Length} файлов");

// Ленивое чтение файлов
// GetFiles — загружает все пути сразу в массив string[]
string[] allFiles = Directory.GetFiles(catalogName);
Console.WriteLine(allFiles.GetType().FullName, allFiles.Length);
Console.WriteLine(allFiles.Length);

// EnumerateFiles — ленивое перечисление, IEnumerable<string>
var lazyFiles = Directory.EnumerateFiles(catalogName, "*.txt");
Console.WriteLine(lazyFiles.GetType().FullName);
int i = 0;
foreach (string file in lazyFiles)
{
    // Файлы читаются по одному — не нужно ждать полной загрузки списка
    Console.WriteLine(file);
    i++;
    if (i >= 3) break;
}


// Пример проверки существования файла:
string filePath = @"c:\output\report.txt";

if (File.Exists(filePath))
{
    Console.WriteLine("Файл найден: " + filePath);

    // Метаданные файла
    DateTime created = File.GetCreationTime(filePath);
    DateTime modified = File.GetLastWriteTime(filePath);
    DateTime accessed = File.GetLastAccessTime(filePath);

    Console.WriteLine($"Создан:       {created:dd.MM.yyyy HH:mm}");
    Console.WriteLine($"Изменён:      {modified:dd.MM.yyyy HH:mm}");
    Console.WriteLine($"Открывался:   {accessed:dd.MM.yyyy HH:mm}");
}
else
{
    Console.WriteLine("Файл не найден: " + filePath);
}

//Основные методы класса Path:
string fullPath = @"c:\output\report.txt";

// Фрагменты путей
Console.WriteLine(Path.GetFileName(fullPath));
// report.txt
Console.WriteLine(Path.GetFileNameWithoutExtension(fullPath));
// report
Console.WriteLine(Path.GetExtension(fullPath));
// .txt
Console.WriteLine(Path.GetDirectoryName(fullPath));
// C:\projects\myapp\data

// Изменить расширение
string csvPath = Path.ChangeExtension(fullPath, ".csv");
Console.WriteLine(csvPath);
// C:\projects\myapp\data\report.csv

// Получить абсолютный путь из относительного
string absPath = Path.GetFullPath(@"data\report.txt");
Console.WriteLine(absPath);
// C:\текущий_каталог\data\report.txt

// Path.Combine — объединение фрагментов путей
string path3 = Path.Combine(@"c:\docs", "report.txt");  // c:\docs\report.txt
Console.WriteLine(path3);
string path4 = Path.Combine(@"c:\docs", "2024", "report.txt"); // три части
Console.WriteLine(path4);

Console.WriteLine("***********************************************");

/*
//Пример ввода строки и сохранения в файл
string currentPath = AppContext.BaseDirectory;

Console.Write("Введите текст для записи в файл: ");
string file1Contents = Console.ReadLine();

// Формирование имени файла
string file1Name = Path.Combine(currentPath, "file1.txt");

// Запись строки в файл
File.WriteAllText(file1Name, file1Contents);

// Чтение строки из файла
string file1ContentsRead = File.ReadAllText(file1Name);
Console.WriteLine("Чтение строки из файла: " + file1ContentsRead);
*/

/*
//Пример ведения текстового журнала событий
string logFile = Path.Combine(AppContext.BaseDirectory, "log.txt");

// WriteAllText — создаёт файл или перезаписывает существующий
File.WriteAllText(logFile, $"[{DateTime.Now:dd.MM.yyyy HH:mm}] Запуск программы\n");

// AppendAllText — добавляет текст в конец файла
File.AppendAllText(logFile, $"[{DateTime.Now:dd.MM.yyyy HH:mm}] Шаг 1 выполнен\n");
File.AppendAllText(logFile, $"[{DateTime.Now:dd.MM.yyyy HH:mm}] Шаг 2 выполнен\n");

// AppendAllLines — добавляет массив строк в конец файла
// каждая строка завершается переводом строки автоматически
string[] newEvents = {
    $"[{DateTime.Now:dd.MM.yyyy HH:mm}] Шаг 3 выполнен",
    $"[{DateTime.Now:dd.MM.yyyy HH:mm}] Завершение программы"
};
File.AppendAllLines(logFile, newEvents);

Console.WriteLine("Содержимое журнала:");
Console.WriteLine(File.ReadAllText(logFile));
*/

/*
//Пример ввода строк с клавиатуры и сохранения в файл
Console.WriteLine("Введите строки для записи в файл " +
    "(пустая строка — окончание ввода):");

string tempStrTrim = "";

// Список строк
List<string> list = new List<string>();

do
{
    // Временная переменная для хранения строки
    string tempStr = Console.ReadLine();
    // Удаление пробелов в начале и конце введённой строки
    tempStrTrim = tempStr.Trim();

    if (tempStrTrim != "")
    {
        // Непустая строка сохраняется в список
        list.Add(tempStrTrim);
    }
}
while (tempStrTrim != "");

// Формирование имени файла
string file2Name = Path.Combine(AppContext.BaseDirectory, "file2.txt");

// Запись в файл массива строк
File.WriteAllLines(file2Name, list.ToArray());

// Чтение строк из файла
string[] file2ContentsRead = File.ReadAllLines(file2Name);
Console.WriteLine("Чтение строк из файла:");
foreach (string str in file2ContentsRead)
{
    Console.WriteLine(str);
}
*/

/*
// Ленивое чтение строк
string fileName = Path.Combine(AppContext.BaseDirectory, "file2.txt");

// ReadAllLines — загружает все строки в массив сразу
string[] allLines = File.ReadAllLines(fileName);
Console.WriteLine($"ReadAllLines: загружено {allLines.Length} строк");

// ReadLines — читает строки по одной, работает с foreach
Console.WriteLine("ReadLines:");
foreach (string line in File.ReadLines(fileName))
{
    Console.WriteLine(line);
}
*/

/*
string fileName = Path.Combine(AppContext.BaseDirectory, "poem.txt");
string fileContent = File.ReadAllText(fileName);

// Разбивка на строки по символу перевода строки
string[] lines = fileContent.Split('\n');
Console.WriteLine($"Строк в файле: {lines.Length}");

// Разбивка на слова по пробелу
string[] words = fileContent.Split(' ');
Console.WriteLine($"Слов в файле: {words.Length}");

// Разбивка одновременно по нескольким разделителям
char[] separators = { ' ', '\n', '\r', '\t' };
string[] tokens = fileContent.Split(separators,
    StringSplitOptions.RemoveEmptyEntries);
Console.WriteLine($"Токенов в файле: {tokens.Length}");

// Вывод файла по строкам, пробелы и концы строк заменены на символ |
foreach(string line in lines)
{
    string[] lineWords = line.Trim().Split(' ');
    foreach (var item in lineWords)
    {
        Console.Write(item.Trim());
        Console.Write('|');
    }
    Console.WriteLine();
}
*/

/*
string sourceFile = Path.Combine(AppContext.BaseDirectory, "image.jpg");
string destFile = Path.Combine(AppContext.BaseDirectory, "image_copy.jpg");

// Чтение файла как последовательности байтов
byte[] fileBytes = File.ReadAllBytes(sourceFile);
Console.WriteLine($"Размер файла: {fileBytes.Length} байт");

// Запись байтов в новый файл
File.WriteAllBytes(destFile, fileBytes);
Console.WriteLine("Файл скопирован: " + destFile);
*/






