﻿// ─── Данные ───────────────────────────────────────────────────────

string[] surnames =
{
    "Иванов", "Петров", "Сидоров", "Кузнецов", "Смирнов",
    "Попов", "Волков", "Новиков"
};

string[] subjects =
{
    "Математика", "Физика", "Информатика", "История", "Химия"
};

// ─── Разбор аргументов ───────────────────────────────────────────

if (args.Length == 0)
{
    PrintUsage();
    return;
}

string mode = args[0].ToLower();

switch (mode)
{
    case "generate":
        Generate();
        break;

    case "filter":
        if (args.Length < 2)
        {
            Console.Error.WriteLine("[ОШИБКА] Режим filter требует второй аргумент — минимальную оценку.");
            Console.Error.WriteLine("Пример: program.exe filter 4");
            return;
        }
        if (!int.TryParse(args[1], out int minGrade) || minGrade < 2 || minGrade > 5)
        {
            Console.Error.WriteLine($"[ОШИБКА] Некорректная оценка: \"{args[1]}\". Допустимые значения: 2..5.");
            return;
        }
        Filter(minGrade);
        break;

    default:
        Console.Error.WriteLine($"[ОШИБКА] Неизвестный режим: \"{mode}\".");
        PrintUsage();
        break;
}

// ─── Локальные функции ───────────────────────────────────────────

void PrintUsage()
{
    Console.Error.WriteLine("=== Программа обработки оценок ===");
    Console.Error.WriteLine("Использование:");
    Console.Error.WriteLine("  program.exe generate            — сгенерировать 20 строк с оценками");
    Console.Error.WriteLine("  program.exe filter <мин_оценка> — отфильтровать строки из stdin");
    Console.Error.WriteLine();
    Console.Error.WriteLine("Примеры:");
    Console.Error.WriteLine("  program.exe generate > grades.csv");
    Console.Error.WriteLine("  program.exe generate | program.exe filter 4");
    Console.Error.WriteLine("  program.exe generate | program.exe filter 4 > good.csv");
}

void Generate()
{
    Console.Error.WriteLine("[generate] Генерация 20 записей...");

    var rnd = new Random();

    for (int i = 0; i < 20; i++)
    {
        string surname = surnames[rnd.Next(surnames.Length)];
        string subject = subjects[rnd.Next(subjects.Length)];
        int grade = rnd.Next(2, 6); // от 2 до 5 включительно

        Console.WriteLine($"{surname};{subject};{grade}");
    }

    Console.Error.WriteLine("[generate] Готово. Выведено 20 строк в stdout.");
}

void Filter(int minGrade)
{
    Console.Error.WriteLine($"[filter] Фильтрация: оценка >= {minGrade}");

    int totalRead = 0;
    int totalPassed = 0;
    string? line;

    while ((line = Console.ReadLine()) != null)
    {
        totalRead++;

        string[] parts = line.Split(';');

        if (parts.Length < 3)
        {
            Console.Error.WriteLine($"[filter] Пропуск некорректной строки #{totalRead}: \"{line}\"");
            continue;
        }

        if (!int.TryParse(parts[2].Trim(), out int grade))
        {
            Console.Error.WriteLine($"[filter] Не удалось разобрать оценку в строке #{totalRead}: \"{line}\"");
            continue;
        }

        if (grade >= minGrade)
        {
            Console.WriteLine(line);
            totalPassed++;
        }
    }

    Console.Error.WriteLine($"[filter] Готово. Прочитано: {totalRead}, прошло фильтр: {totalPassed}, отброшено: {totalRead - totalPassed}.");
}
