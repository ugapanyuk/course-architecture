﻿using System;
using System.IO;

// ================= ПОИСК ТЕКСТОВЫХ ФАЙЛОВ =================

Console.WriteLine("================================");
Console.WriteLine("   ПОИСК ТЕКСТОВЫХ ФАЙЛОВ (.txt)");
Console.WriteLine("================================");
Console.WriteLine();

Console.Write("Введите путь к каталогу: ");
string inputPath = Console.ReadLine()?.Trim() ?? "";

Console.WriteLine();

// Проверка: пользователь не ввёл пустую строку
if (String.IsNullOrWhiteSpace(inputPath))
{
    Console.WriteLine("Ошибка: путь к каталогу не введён.");
}
// Проверка существования каталога
else if (!Directory.Exists(inputPath))
{
    Console.WriteLine($"Ошибка: каталог не существует: {inputPath}");
}
else
{
    // Каталог существует — выполняем поиск
    SearchTextFiles(inputPath);
}

// ================= ФУНКЦИИ =================

/// <summary>
/// Выполняет поиск всех файлов .txt в указанном каталоге
/// и всех его подкаталогах, выводит информацию о каждом файле
/// </summary>
/// <param name="rootPath">Путь к корневому каталогу поиска</param>
static void SearchTextFiles(string rootPath)
{
    Console.WriteLine($"Поиск в каталоге: {rootPath}");
    Console.WriteLine();

    // Получение списка всех .txt файлов в каталоге и подкаталогах
    // SearchOption.AllDirectories — рекурсивный поиск по подкаталогам
    string[] files = Directory.GetFiles(rootPath, "*.txt",
        SearchOption.AllDirectories);

    if (files.Length == 0)
    {
        Console.WriteLine("Текстовые файлы (.txt) не найдены.");
        return;
    }

    // Заголовок таблицы результатов
    PrintTableHeader();

    // Вывод информации о каждом найденном файле
    foreach (string filePath in files)
    {
        PrintFileInfo(filePath, rootPath);
    }

    // Итоговое количество найденных файлов
    Console.WriteLine(new string('-', 72));
    Console.WriteLine($"Итого найдено файлов: {files.Length}");
}

/// <summary>
/// Выводит заголовок таблицы результатов
/// </summary>
static void PrintTableHeader()
{
    Console.WriteLine(new string('-', 72));
    Console.WriteLine($"{"Имя файла",-28} {"Дата изменения",-18} Каталог");
    Console.WriteLine(new string('-', 72));
}

/// <summary>
/// Выводит информацию об одном файле:
/// имя файла, дату последнего изменения и путь к каталогу
/// </summary>
/// <param name="filePath">Полный путь к файлу</param>
/// <param name="rootPath">Корневой каталог поиска для сокращения вывода</param>
static void PrintFileInfo(string filePath, string rootPath)
{
    // Имя файла без пути
    string fileName = Path.GetFileName(filePath);

    // Дата последнего изменения файла
    DateTime lastModified = File.GetLastWriteTime(filePath);
    string lastModifiedStr = lastModified.ToString("dd.MM.yyyy HH:mm");

    // Путь к каталогу, содержащему файл
    string fileDir = Path.GetDirectoryName(filePath);

    // Для удобства чтения выводим путь к каталогу
    // относительно корневого каталога поиска
    string relativePath = GetRelativePath(rootPath, fileDir);

    Console.WriteLine($"{fileName,-28} {lastModifiedStr,-18} {relativePath}");
}

/// <summary>
/// Возвращает путь к каталогу относительно корневого каталога.
/// Если каталог совпадает с корневым — возвращает точку «.»
/// </summary>
/// <param name="rootPath">Корневой каталог</param>
/// <param name="fullPath">Полный путь к каталогу</param>
/// <returns>Относительный путь или полный путь если не удалось сократить</returns>
static string GetRelativePath(string rootPath, string fullPath)
{
    // Нормализация путей для корректного сравнения
    string normalRoot = rootPath.TrimEnd(Path.DirectorySeparatorChar);
    string normalFull = fullPath.TrimEnd(Path.DirectorySeparatorChar);

    // Если каталог файла совпадает с корневым — возвращаем «.»
    if (string.Equals(normalRoot, normalFull,
        StringComparison.OrdinalIgnoreCase))
    {
        return ".";
    }

    // Если путь начинается с корневого — убираем его из начала
    if (normalFull.StartsWith(normalRoot,
        StringComparison.OrdinalIgnoreCase))
    {
        // +1 для удаления символа разделителя каталогов
        return normalFull.Substring(normalRoot.Length + 1);
    }

    // В остальных случаях возвращаем полный путь
    return fullPath;
}
