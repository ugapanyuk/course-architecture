﻿using System;
using System.IO;

// ================= МЕНЕДЖЕР ЗАМЕТОК =================

// Путь к файлу заметок в каталоге приложения
string notesFile = Path.Combine(AppContext.BaseDirectory, "notes.txt");

// Проверка существования файла при запуске
if (!File.Exists(notesFile))
{
    Console.WriteLine("Файл заметок не найден, будет создан новый.");
}
else
{
    Console.WriteLine($"Файл заметок найден: {notesFile}");
}

Console.WriteLine();

// Главный цикл меню — выполняется до выбора пункта 0
string choice = "";
do
{
    PrintMenu();
    choice = Console.ReadLine()?.Trim() ?? "";
    Console.WriteLine();

    switch (choice)
    {
        case "1":
            AddNote(notesFile);
            break;
        case "2":
            ShowAllNotes(notesFile);
            break;
        case "3":
            SearchNotes(notesFile);
            break;
        case "4":
            ClearNotes(notesFile);
            break;
        case "0":
            Console.WriteLine("До свидания!");
            break;
        default:
            Console.WriteLine("Неверный пункт меню. Попробуйте снова.");
            break;
    }

    Console.WriteLine();
}
while (choice != "0");

// ================= ФУНКЦИИ =================

/// <summary>
/// Выводит главное меню программы
/// </summary>
static void PrintMenu()
{
    Console.WriteLine("================================");
    Console.WriteLine("        МЕНЕДЖЕР ЗАМЕТОК       ");
    Console.WriteLine("================================");
    Console.WriteLine("  1 — Добавить заметку");
    Console.WriteLine("  2 — Показать все заметки");
    Console.WriteLine("  3 — Найти заметки по слову");
    Console.WriteLine("  4 — Очистить все заметки");
    Console.WriteLine("  0 — Выход");
    Console.WriteLine("================================");
    Console.Write("Ваш выбор: ");
}

/// <summary>
/// Добавляет новую заметку в конец файла с отметкой даты и времени
/// </summary>
/// <param name="filePath">Путь к файлу заметок</param>
static void AddNote(string filePath)
{
    Console.Write("Введите текст заметки: ");
    string noteText = Console.ReadLine() ?? "";

    // Проверка: заметка не должна быть пустой
    if (String.IsNullOrWhiteSpace(noteText))
    {
        Console.WriteLine("Заметка не добавлена: текст пустой.");
        return;
    }

    // Формирование строки заметки с датой и временем
    // DateTime.Now возвращает текущую дату и время
    string timestamp = DateTime.Now.ToString("[dd.MM.yyyy HH:mm]");
    string noteLine = $"{timestamp} {noteText}{Environment.NewLine}";

    // File.AppendAllText — дозапись в конец файла
    // Если файл не существует, он будет создан автоматически
    File.AppendAllText(filePath, noteLine);

    Console.WriteLine("Заметка успешно добавлена.");
}

/// <summary>
/// Выводит все заметки из файла с нумерацией строк
/// </summary>
/// <param name="filePath">Путь к файлу заметок</param>
static void ShowAllNotes(string filePath)
{
    if (!File.Exists(filePath))
    {
        Console.WriteLine("Файл заметок не найден.");
        return;
    }

    Console.WriteLine("-------- Все заметки ----------");

    int lineNumber = 1;

    // File.ReadLines — читает строки по одной без загрузки всего файла
    foreach (string line in File.ReadLines(filePath))
    {
        // Пропускаем пустые строки
        if (!String.IsNullOrWhiteSpace(line))
        {
            // Выравнивание номера строки по правому краю в поле шириной 3
            Console.WriteLine($"{lineNumber,3}. {line}");
            lineNumber++;
        }
    }

    if (lineNumber == 1)
    {
        Console.WriteLine("Заметок пока нет.");
    }
    else
    {
        Console.WriteLine("-------------------------------");
        Console.WriteLine($"Итого заметок: {lineNumber - 1}");
    }
}

/// <summary>
/// Выводит только те заметки, которые содержат заданное слово
/// </summary>
/// <param name="filePath">Путь к файлу заметок</param>
static void SearchNotes(string filePath)
{
    if (!File.Exists(filePath))
    {
        Console.WriteLine("Файл заметок не найден.");
        return;
    }

    Console.Write("Введите слово для поиска: ");
    string searchWord = Console.ReadLine() ?? "";

    if (String.IsNullOrWhiteSpace(searchWord))
    {
        Console.WriteLine("Слово для поиска не введено.");
        return;
    }

    Console.WriteLine($"---- Поиск по слову \"{searchWord}\" ----");

    int foundCount = 0;
    int lineNumber = 1;

    foreach (string line in File.ReadLines(filePath))
    {
        if (!String.IsNullOrWhiteSpace(line))
        {
            // string.Contains — проверка вхождения подстроки
            // StringComparison.OrdinalIgnoreCase — поиск без учёта регистра
            if (line.Contains(searchWord, StringComparison.OrdinalIgnoreCase))
            {
                Console.WriteLine($"{lineNumber,3}. {line}");
                foundCount++;
            }
            lineNumber++;
        }
    }

    Console.WriteLine("-------------------------------");

    if (foundCount == 0)
    {
        Console.WriteLine($"Заметок со словом \"{searchWord}\" не найдено.");
    }
    else
    {
        Console.WriteLine($"Найдено заметок: {foundCount}");
    }
}

/// <summary>
/// Удаляет все заметки после подтверждения пользователем
/// </summary>
/// <param name="filePath">Путь к файлу заметок</param>
static void ClearNotes(string filePath)
{
    if (!File.Exists(filePath))
    {
        Console.WriteLine("Файл заметок не найден.");
        return;
    }

    Console.Write("Вы уверены, что хотите удалить все заметки? (да/нет): ");
    string confirm = Console.ReadLine()?.Trim().ToLower() ?? "";

    if (confirm == "да")
    {
        // File.WriteAllText с пустой строкой перезаписывает файл целиком,
        // удаляя всё предыдущее содержимое
        File.WriteAllText(filePath, "");
        Console.WriteLine("Все заметки удалены.");
    }
    else
    {
        Console.WriteLine("Очистка отменена.");
    }
}
