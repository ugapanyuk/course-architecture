﻿using System.Text;

Console.OutputEncoding = Encoding.UTF8;
Console.InputEncoding = Encoding.UTF8;

if (args.Length == 0)
{
    Console.Error.WriteLine("Использование:");
    Console.Error.WriteLine("  produce_consume produce                     — вывод данных");
    Console.Error.WriteLine("  produce_consume consume                     — обработка данных");
    Console.Error.WriteLine("  produce_consume produce > data.csv          — вывод в файл");
    Console.Error.WriteLine("  produce_consume consume < data.csv          — ввод из файла");
    Console.Error.WriteLine("  produce_consume produce | tool consume      — конвейер");
    return;
}

switch (args[0].ToLower())
{
    case "produce":
        Produce();
        break;
    case "consume":
        Consume();
        break;
    default:
        Console.Error.WriteLine($"Неизвестная команда: {args[0]}");
        break;
}

void Produce()
{
    string[] cities = { "Москва", "Санкт-Петербург", "Новосибирск",
                        "Екатеринбург", "Казань" };
    Random rng = new(42);

    for (int i = 0; i < 10; i++)
    {
        string city = cities[rng.Next(cities.Length)];
        int temperature = rng.Next(-25, 36);
        // Вывод в stdout — может быть перенаправлен в файл или конвейер
        Console.WriteLine($"{city};{temperature}");
    }

    // Диагностика в stderr — всегда отображается на экране
    Console.Error.WriteLine("[produce] Сгенерировано 10 измерений");
}

void Consume()
{
    Dictionary<string, List<int>> data = new();
    int lineCount = 0;

    string? line;
    // ReadLine() вернёт null при окончании файла, потока или по Ctrl+Z/Ctrl+D
    while ((line = Console.ReadLine()) is not null)
    {
        lineCount++;
        string[] parts = line.Split(';');
        if (parts.Length != 2 || !int.TryParse(parts[1], out int temp))
        {
            Console.Error.WriteLine($"[consume] Пропущена строка: {line}");
            continue;
        }

        string city = parts[0];
        if (!data.ContainsKey(city))
            data[city] = new List<int>();
        data[city].Add(temp);
    }

    Console.WriteLine($"Обработано строк: {lineCount}");
    Console.WriteLine(new string('-', 40));
    foreach (var pair in data.OrderBy(p => p.Key))
    {
        double avg = pair.Value.Average();
        int min = pair.Value.Min();
        int max = pair.Value.Max();
        Console.WriteLine($"{pair.Key}: среднее={avg:F1}, мин={min}, макс={max}");
    }

    Console.Error.WriteLine($"[consume] Обработано {lineCount} строк");
}
