﻿using System.Data;
using System.Text;
using temp;
using static System.Net.WebRequestMethods;
using static System.Reflection.Metadata.BlobBuilder;

namespace temp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            var c = new Circle(5);
            Console.WriteLine(c.Area);
            Console.WriteLine(c.Description);

        }
    }

    abstract class Shape
    {
        public string Name { get; }

        public Shape(string name) { Name = name; }

        // Абстрактное свойство
        public abstract double Area { get; }

        // Виртуальное свойство с реализацией по умолчанию
        public virtual string Description => $"{Name}: площадь = {Area:F2}";
    }

    class Circle : Shape
    {
        public double Radius { get; }

        public Circle(double radius) : base("Круг")
        {
            Radius = radius;
        }

        // Реализация абстрактного свойства
        public override double Area => Math.PI * Radius * Radius;

        // Переопределение виртуального свойства
        public override string Description
            => $"{Name} (R={Radius}): площадь = {Area:F2}";
    }


    ////////////////////////////////////////////////////////////////////////////////


    /// <summary>
    /// Разработчик (основная таблица, сторона «много»)
    /// </summary>
    class Developer
    {
        /// <summary>Идентификатор разработчика</summary>
        public int Id { get; set; }

        /// <summary>Идентификатор отдела (внешний ключ)</summary>
        public int DepartmentId { get; set; }

        /// <summary>Имя разработчика</summary>
        public string Name { get; set; }

        private int _commits;
        /// <summary>
        /// Количество коммитов (не может быть отрицательным)
        /// </summary>
        public int Commits
        {
            get => _commits;
            set
            {
                if (value < 0)
                    throw new ArgumentException(
                        "Количество коммитов не может быть отрицательным");
                _commits = value;
            }
        }

        /// <summary>Конструктор с параметрами</summary>
        public Developer(int id, int departmentId, string name, int commits)
        {
            Id = id;
            DepartmentId = departmentId;
            Name = name;
            Commits = commits;
        }

        /// <summary>Конструктор по умолчанию</summary>
        public Developer() : this(0, 0, "", 0) { }

        public override string ToString()
            => $"[{Id}] {Name}, отдел #{DepartmentId}, коммитов: {Commits}";
    }











}
