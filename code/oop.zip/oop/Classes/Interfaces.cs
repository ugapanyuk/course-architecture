﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes
{
    interface I1
    {
        string I1_method();
    }

    interface I2 : I1
    {
        string I2_method();
    }

    interface IDescribable
    {
        string GetTitle();

        // Метод по умолчанию — реализующий класс
        // может его не переопределять
        string GetDescription() => $"Объект: {GetTitle()}";
    }

    class Book : IDescribable
    {
        public string Title { get; init; }
        public Book(string title) { Title = title; }

        // Обязательный метод — реализуется в классе
        public string GetTitle() => Title;

        // GetDescription() можно не реализовывать:
        // будет использована реализация интерфейса
    }

    class ExtendedClass2 : ExtendedClass1, I1, I2
    {
        // В конструкторе вызывается конструктор базового класса
        public ExtendedClass2(int pi, int pi2, int pi3)
                : base(pi, pi2, pi3) { }

        // Реализация методов, объявленных в интерфейсах
        public string I1_method() { return ToString(); }
        public string I2_method() { return ToString(); }
    }

    /*
    class ClassForI1 : I1
    {
        // реализовать интерфейс
        public string I1_method()
        {
            throw new NotImplementedException();
        }

        // реализовать интерфейс явно
        string I1.I1_method()
        {
            throw new NotImplementedException();
        }
    }
    */

    class ClassForI1 : I1
    {
        // Неявная реализация
        public string I1_method()
        {
            return "1";
        }

        // Явная реализация
        string I1.I1_method()
        {
            return "2";
        }
    }




}
