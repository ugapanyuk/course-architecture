﻿using Classes;
using System;
using System.Collections.Generic;
using System.Text;

namespace Classes
{
    internal class BaseClass
    {
        private int i;

        //Конструктор
        public BaseClass(int param) { i = param; }
        //Методы с различными сигнатурами
        public int MethodReturn(int a) { return i; }
        public string MethodReturn(string a) { return i.ToString(); }

        //Свойство
        //private-значение, которое хранит данные для свойства
        private int _property1 = 0;
        //объявление свойства
        public int Property1
        {
            //возвращаемое значение
            get { return _property1; }
            //установка значения, value - ключевое слово
            set { _property1 = value; }
            //private set { _property1 = value; }
        }

        /// <summary>
        /// Вычисляемое свойство
        /// </summary>
        public int Property1mul2
        {
            get { return Property1 * 2; }
        }

        //Автоматически реализуемые свойства
        //поддерживающая переменная создается автоматически
        public string Property2 { get; set; } = "Строка";
        public float Property3 { get; private set; }

    }
}


/// <summary>
/// Наследуемый класс 1
/// </summary>
class ExtendedClass1 : BaseClass
{
    private int i2;
    private int i3;

    //Конструктор
    //base(pi) - вызов конструктора базового класса
    public ExtendedClass1(int pi, int pi2) : base(pi) { i2 = pi2; }

    //this(pi, pi2) - вызов другого конструктора этого класса
    public ExtendedClass1(int pi, int pi2, int pi3) : this(pi, pi2) { i3 = pi3; }

    /// <summary>
    /// Метод виртуальный, так как он объявлен в самом базовом классе object
    /// поэтому чтобы его переопределить добавлено ключевое слово override
    /// </summary>
    /// <returns></returns>
    public override string ToString()
    {
        return "i=" + MethodReturn("1") + " i2=" + i2.ToString() + " i3=" + i3.ToString();
    }

}

/// <summary>
/// Наследуемый класс 2
/// </summary>
class ExtendedClass2 : ExtendedClass1
{
    //В конструкторе вызывается конструктор базового класса
    public ExtendedClass2(int pi, int pi2, int pi3) : base(pi, pi2, pi3) { }
}

/// <summary>
/// Метод расширения
/// </summary>
static class ExtendedClass2Extension
{
    public static int ExtendedClass2NewMethod(this ExtendedClass2 ec2, int i)
    {
        return i + 1;
    }
}
