﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Classes
{

    /// <summary>
    /// Пример класса для перегрузки операторов.
    /// Реализует IEquatable<Number> и IComparable<Number>
    /// для интеграции с коллекциями и LINQ.
    /// </summary>
    public class Number : IEquatable<Number>, IComparable<Number>
    {
        /// <summary>
        /// Целое число
        /// </summary>
        public int Num { get; protected set; }

        /// <summary>
        /// Конструктор
        /// </summary>
        public Number(int param)
        {
            Num = param;
            Console.WriteLine($"Вызов конструктора для {param}"); // (изм.) интерполяция
        }

        /// <summary>
        /// Приведение к строке
        /// </summary>
        public override string ToString() => Num.ToString(); // (изм.) expression-bodied

        // ── Унарные операторы ─────────────────────────────────────

        /// <summary>
        /// Перегрузка унарного оператора ++.
        /// Префиксную и постфиксную формы компилятор различает автоматически.
        /// </summary>
        public static Number operator ++(Number lhs)
        {
            // Возвращаем НОВЫЙ объект — не изменяем переданный операнд.
            // Это правильная практика: компилятор сам присвоит результат
            // обратно в переменную при выполнении a++ или ++a.
            return new Number(lhs.Num + 1);
        }

        // ── Бинарные операторы ────────────────────────────────────

        /// <summary>
        /// Перегрузка бинарного оператора для (Number + Number)
        /// </summary>
        public static Number operator +(Number lhs, Number rhs)
            => new Number(lhs.Num + rhs.Num); // (изм.) expression-bodied

        /// <summary>
        /// Перегрузка бинарного оператора для (Number + int).
        /// Методы перегрузки операторов поддерживают полиморфизм по типу операндов.
        /// </summary>
        public static Number operator +(Number lhs, int rhs)
            => new Number(lhs.Num + rhs);

        /// <summary>
        /// Контрпример: оператор * изменяет левый операнд вместо создания нового объекта.
        /// Это плохая практика — оператор неявно мутирует один из операндов.
        /// </summary>
        public static Number operator *(Number lhs, int rhs)
        {
            lhs.Num = lhs.Num * rhs; // изменяем переданный объект — плохая практика
            return lhs;
        }

        // ── Операторы равенства ───────────────────────────────────

        public static bool operator ==(Number lhs, Number rhs)
            => lhs.Num == rhs.Num;

        public static bool operator !=(Number lhs, Number rhs)
            => !(lhs == rhs);

        // Реализация IEquatable<Number> —
        // обеспечивает корректную работу с коллекциями и LINQ
        /// <summary>
        /// Типобезопасное сравнение (IEquatable)
        /// </summary>
        public bool Equals(Number? other)
            => other is not null && Num == other.Num;

        public override bool Equals(object? obj)
            => obj is Number other && Equals(other);

        public override int GetHashCode()
            => Num.GetHashCode();

        // ── Операторы сравнения ───────────────────────────────────

        // Реализация IComparable<Number> —
        // позволяет использовать OrderBy, Min, Max, Array.Sort и т.д.
        /// <summary>
        /// Сравнение объектов (IComparable)
        /// </summary>
        public int CompareTo(Number? other)
            => other is null ? 1 : Num.CompareTo(other.Num);

        public static bool operator <(Number lhs, Number rhs)
            => lhs.CompareTo(rhs) < 0;

        public static bool operator >(Number lhs, Number rhs)
            => lhs.CompareTo(rhs) > 0;

        public static bool operator <=(Number lhs, Number rhs)
            => lhs.CompareTo(rhs) <= 0;

        public static bool operator >=(Number lhs, Number rhs)  // (изм.) было => (ошибка)
            => lhs.CompareTo(rhs) >= 0;

        // ── Операторы приведения типов ────────────────────────────

        /// <summary>
        /// Явное приведение типа Number к типу int
        /// </summary>
        public static explicit operator int(Number lhs)
            => lhs.Num;

        /// <summary>
        /// Неявное приведение типа Number к типу double
        /// </summary>
        public static implicit operator double(Number lhs)
            => (double)lhs.Num;

        // ── Индексатор ────────────────────────────────────────────

        /// <summary>
        /// Пример индексатора
        /// </summary>
        public int this[int i]
        {
            get => Num + i;
            set => Num = value + i;
        }
    }
}
