﻿using Classes;
using System.Xml.Linq;
using static System.Net.WebRequestMethods;

Console.WriteLine("Базовый класс");

//Объект базового класса
BaseClass bc = new BaseClass(333);
Console.WriteLine(bc.MethodReturn(1));
Console.WriteLine(bc.MethodReturn("1"));

//Обращение к свойству
bc.Property1 = 334;
Console.WriteLine("\n property1 = {0}", bc.Property1);

Console.WriteLine("\nНаследуемый класс 1");
//Объекты наследуемого класса
ExtendedClass1 ex1_1 = new ExtendedClass1(1, 2);
//Неявно вызывается метод ex1.ToString()
Console.WriteLine(ex1_1);

ExtendedClass1 ex1_2 = new ExtendedClass1(1, 2, 3);
Console.WriteLine(ex1_2);

Console.WriteLine("\nНаследуемый класс 2");

ExtendedClass2 obj = new ExtendedClass2(100, 200, 300);

// Вызов метода расширения — как обычного метода объекта
int result = obj.ExtendedClass2NewMethod(2); 

// Эквивалентный вызов через статический метод
int result2 = ExtendedClass2Extension.ExtendedClass2NewMethod(obj, 2);
Console.WriteLine($"{result}, {result2}");

Console.WriteLine("\nЧастичный класс");
PartialClass part = new PartialClass(333, 334);
Console.WriteLine(part);

ClassForI1 c1 = new ClassForI1();
string str1 = c1.I1_method();   // неявная реализация → "1"

I1 i1 = (I1)c1;
string str2 = i1.I1_method();   // явная реализация → "2"

Console.WriteLine(str1 + str2); // 12

Point p1 = new Point(1.0, 2.0);
Point p2 = new Point(4.0, 6.0);
Console.WriteLine(p1.DistanceTo(p2)); // 5

Point a = new Point(1.0, 2.0);
Point b = a;       // создаётся копия данных

b.X = 99.0;

Console.WriteLine(a); // (1, 2)  ← не изменился
Console.WriteLine(b); // (99, 2)








